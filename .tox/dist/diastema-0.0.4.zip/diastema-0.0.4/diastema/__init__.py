"""A package to analyse intervals and melodies.

.. moduleauthor:: Anas Ghrab <anas.ghrab@gmail.com>

"""

import intervalles
import diastema


def start():
    "This starts this module running ..."